const msg = {
    lastUpdated: "Updated at: ",
    lastStored: "Stored at: ",
    read: "Reader",
    write: "Writer",
    add: "Add",
    back: "Back"
}